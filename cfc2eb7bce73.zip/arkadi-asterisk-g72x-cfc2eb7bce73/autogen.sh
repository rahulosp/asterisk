#!/bin/sh

autoreconf -fi
rm -Rf autom4te*.cache
